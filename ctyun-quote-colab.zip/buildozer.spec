[app]

# 应用基本信息
title = 天翼云等保报价系统
package.name = CtyunQuote
package.domain = com.ctyun.quote
version = 1.0.0
version.regex = 
version.code = 1

# 入口脚本
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,html,css,js,xlsx,txt
source.exclude_exts = spec
source.exclude_dirs = tests, bin, .git, __pycache__, build, dist, *.egg-info, .workbuddy

# 构建需求（关键）
requirements = python3,flask,openpyxl,jinja2

# Android 特定配置
android.api = 34
android.minapi = 21
android.sdk = 34
android.ndk = 25c
android.accept_sdk_license = True
android.archs = arm64-v8a
android.add_webview = True
android.allow_downloads = True
android.wakelock = True
android.enable_androidx = True
android.manifest.intent_filters = 
android.gradle_dependencies = 
android.add_src = 

# 权限
android.permissions = INTERNET,ACCESS_NETWORK_STATE,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE

# 图标（可选）
android.icon = icons/icon.png
android.icon_adaptive_background = 
android.icon_adaptive_foreground = 

# 日志和调试
android.logcat_filters = *:S python:D
android.preserve_libc = True

# 应用元数据
osx.icon = 
osx.codesign.certificate = 
osx.codesign.identity = 

# iOS（暂不配置）
ios.icon = 
ios.archs = arm64
ios.deployment_target = 15.0

# 构建输出
log_level = 2
dirs_to_lint = 
locale_list = zh_CN

# 白名单
android.add_jars = 
android.extra_jars = 
android.entrypoint = android_main.py
android.app_class = 
android.welcome_image = 

# 编译选项
# 内存优化
android.ndk_arm = arm64-v8a
android.ndk_api = 34


[buildozer]

# 下载目录（缓存 SDK/NDK）
cache_dir = ./cache


[app:android]

# 屏幕方向
orientation = portrait
window.icon = 
window.background_color = 0x2C5F8A
window.title = 天翼云等保报价系统